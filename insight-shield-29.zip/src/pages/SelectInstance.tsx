import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useNavigate } from "react-router-dom";
import { Server, Shield, AlertTriangle, ArrowLeft } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";

interface Instance {
  id: number;
  name: string;
  description: string;
  created_at: string;
  updated_at: string;
  user_id: string;
  status?: string;
}

export default function SelectInstance() {
  const [selectedInstance, setSelectedInstance] = useState("");
  const navigate = useNavigate();
  const { toast } = useToast();

  const { data: instances, isLoading } = useQuery({
    queryKey: ['instances'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('instances')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching instances:', error);
        throw error;
      }
      
      return data as Instance[];
    }
  });

  const handleContinue = () => {
    if (selectedInstance) {
      navigate(`/?instanceId=${selectedInstance}`);
    }
  };

  const handleBack = () => {
    navigate("/instance-choice");
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "high": return "text-red-400";
      case "medium": return "text-yellow-400";
      case "low": return "text-green-400";
      default: return "text-gray-400";
    }
  };

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case "high": return <AlertTriangle className="h-5 w-5 text-red-400" />;
      case "medium": return <Shield className="h-5 w-5 text-yellow-400" />;
      case "low": return <Shield className="h-5 w-5 text-green-400" />;
      default: return <Server className="h-5 w-5 text-gray-400" />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-4xl mx-auto">
          <Button 
            variant="ghost" 
            className="mb-6" 
            onClick={handleBack}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Instance Choice
          </Button>

          <Card>
            <CardHeader>
              <CardTitle className="text-2xl font-bold">Select Instance</CardTitle>
              <CardDescription>
                Loading instances...
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    );
  }

  if (!instances?.length) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-4xl mx-auto">
          <Button 
            variant="ghost" 
            className="mb-6" 
            onClick={handleBack}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Instance Choice
          </Button>

          <Card>
            <CardHeader>
              <CardTitle className="text-2xl font-bold">No Instances Found</CardTitle>
              <CardDescription>
                You haven't created any instances yet. Create a new instance to get started.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate("/create-instance")} className="w-full">
                Create New Instance
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <Button 
          variant="ghost" 
          className="mb-6" 
          onClick={handleBack}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Instance Choice
        </Button>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Select Instance</CardTitle>
            <CardDescription>
              Choose the environment instance you want to analyze
            </CardDescription>
          </CardHeader>
          <CardContent>
            <RadioGroup value={selectedInstance} onValueChange={setSelectedInstance}>
              <div className="grid gap-4">
                {instances.map((instance) => (
                  <div key={instance.id} className="relative">
                    <RadioGroupItem 
                      value={instance.id.toString()} 
                      id={instance.id.toString()}
                      className="peer sr-only"
                    />
                    <Label
                      htmlFor={instance.id.toString()}
                      className="flex cursor-pointer rounded-lg border-2 border-muted p-4 hover:bg-accent peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                    >
                      <div className="flex items-start gap-4 w-full">
                        <div className="mt-1">
                          <Server className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <h3 className="font-semibold">{instance.name}</h3>
                            <Badge variant="secondary">
                              Created {new Date(instance.created_at).toLocaleDateString()}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{instance.description}</p>
                          <div className="flex items-center gap-4 text-sm">
                            <span className="text-muted-foreground">
                              Last updated: {new Date(instance.updated_at).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    </Label>
                  </div>
                ))}
              </div>
            </RadioGroup>

            <Button 
              onClick={handleContinue}
              disabled={!selectedInstance}
              className="w-full mt-6"
            >
              Continue to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
