import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Upload, FileSpreadsheet, CheckCircle, ArrowLeft } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function UploadVulnerabilities() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { toast } = useToast();
  
  const instanceId = searchParams.get('instanceId');
  
  if (!instanceId) {
    navigate('/instance-choice');
    return null;
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    setIsUploading(true);
    
    try {
      // TODO: Implement actual file upload and processing
      // For now, we'll just simulate the upload
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "File uploaded successfully",
        description: "Your vulnerability data is being processed.",
      });
      
      // Redirect to dashboard with instance ID
      navigate(`/?instanceId=${instanceId}`);
    } catch (error) {
      console.error('Error uploading file:', error);
      toast({
        title: "Error uploading file",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleBack = () => {
    navigate("/create-instance");
  };

  const isExcelFile = selectedFile && (
    selectedFile.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
    selectedFile.type === "application/vnd.ms-excel" ||
    selectedFile.name.endsWith('.xlsx') ||
    selectedFile.name.endsWith('.xls')
  );

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-2xl mx-auto">
        <Button 
          variant="ghost" 
          className="mb-6" 
          onClick={handleBack}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Instance Creation
        </Button>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Upload Vulnerability Data</CardTitle>
            <CardDescription>
              Upload an Excel file containing vulnerability scan results
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="border-2 border-dashed border-muted rounded-lg p-8 text-center">
              <div className="flex flex-col items-center space-y-4">
                <div className="rounded-full bg-muted p-4">
                  <Upload className="h-8 w-8 text-muted-foreground" />
                </div>
                <div>
                  <Label htmlFor="file-upload" className="cursor-pointer">
                    <span className="text-lg font-medium">Choose Excel file</span>
                    <p className="text-sm text-muted-foreground mt-1">
                      Supported formats: .xlsx, .xls
                    </p>
                  </Label>
                  <Input
                    id="file-upload"
                    type="file"
                    accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </div>
              </div>
            </div>

            {selectedFile && (
              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div className="flex items-center space-x-2">
                  <FileSpreadsheet className="h-5 w-5 text-muted-foreground" />
                  <span className="text-sm font-medium">{selectedFile.name}</span>
                </div>
                <CheckCircle className="h-5 w-5 text-green-500" />
              </div>
            )}

            <Button 
              onClick={handleUpload} 
              disabled={!selectedFile || !isExcelFile || isUploading}
              className="w-full"
            >
              {isUploading ? "Uploading..." : "Upload and Process"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
