
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface VulnerabilityClusteringData {
  product_service: string;
  total_vulnerabilities: number;
  critical: number;
  high: number;
  medium: number;
  low: number;
  affected_hosts: number;
  cve_count: number;
  kev_count: number;
  common_vulnerabilities: string | null;
}

export default function Clustering() {
  const { data: clusteringData, isLoading } = useQuery({
    queryKey: ['vulnerability-clustering'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('vulnerability_clustering')
        .select('*')
        .order('total_vulnerabilities', { ascending: false });
      
      if (error) {
        console.error('Error fetching vulnerability clustering data:', error);
        throw error;
      }
      
      return data as VulnerabilityClusteringData[];
    }
  });

  // Get top 5 clusters for pie chart
  const topClustersData = clusteringData ? 
    clusteringData.slice(0, 5).map((item, index) => ({
      product: item.product_service,
      vulnerabilities: item.total_vulnerabilities,
      color: ["#dc2626", "#ea580c", "#ca8a04", "#16a34a", "#2563eb"][index] || "#6b7280"
    })) : [];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Vulnerability Clustering</h1>
          <p className="text-muted-foreground">This sheet groups vulnerabilities by affected product/service, enabling targeted remediation campaigns and efficient operational planning.</p>
        </div>
        <div className="flex items-center justify-center py-8">
          <p className="text-muted-foreground">Loading vulnerability clustering data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Vulnerability Clustering</h1>
        <p className="text-muted-foreground">This sheet groups vulnerabilities by affected product/service, enabling targeted remediation campaigns and efficient operational planning.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top 5 Clusters Table */}
        <div className="chart-container">
          <h3 className="text-lg font-semibold mb-4">Top 5 Clusters by Vulnerabilities</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4">Product/Service</th>
                  <th className="text-center py-3 px-4">Vulnerabilities</th>
                </tr>
              </thead>
              <tbody>
                {topClustersData.map((item, index) => (
                  <tr key={index} className="border-b border-border/50 hover:bg-muted/20">
                    <td className="py-3 px-4 font-medium">{item.product}</td>
                    <td className="py-3 px-4 text-center font-bold">{item.vulnerabilities.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Vulnerability Distribution by Product/Service */}
        <div className="chart-container">
          <h3 className="text-lg font-semibold mb-4">Vulnerability Distribution by Product/Service</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={topClustersData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="vulnerabilities"
                >
                  {topClustersData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "#1f2937", 
                    border: "1px solid #374151",
                    borderRadius: "8px"
                  }} 
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap justify-center gap-2 mt-4">
            {topClustersData.map((item, index) => (
              <div key={index} className="flex items-center gap-2 text-xs">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: item.color }}
                />
                <span>{item.product}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Detailed Clusters Table */}
      <div className="chart-container">
        <h3 className="text-lg font-semibold mb-4">Detailed Product/Service Analysis</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-2">Product/Service</th>
                <th className="text-center py-3 px-2">Total</th>
                <th className="text-center py-3 px-2">Critical</th>
                <th className="text-center py-3 px-2">High</th>
                <th className="text-center py-3 px-2">Medium</th>
                <th className="text-center py-3 px-2">Low</th>
                <th className="text-center py-3 px-2">Affected Hosts</th>
                <th className="text-center py-3 px-2">CVE Count</th>
                <th className="text-center py-3 px-2">KEV Count</th>
                <th className="text-left py-3 px-2 min-w-[300px]">Common Vulnerabilities</th>
              </tr>
            </thead>
            <tbody>
              {clusteringData?.map((item, index) => (
                <tr key={index} className="border-b border-border/50 hover:bg-muted/20">
                  <td className="py-3 px-2 font-medium">{item.product_service}</td>
                  <td className="py-3 px-2 text-center font-bold">{item.total_vulnerabilities.toLocaleString()}</td>
                  <td className="py-3 px-2 text-center">
                    <Badge variant={item.critical > 0 ? "destructive" : "secondary"}>
                      {item.critical}
                    </Badge>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <Badge variant={item.high > 0 ? "default" : "secondary"}>
                      {item.high}
                    </Badge>
                  </td>
                  <td className="py-3 px-2 text-center">{item.medium}</td>
                  <td className="py-3 px-2 text-center">{item.low}</td>
                  <td className="py-3 px-2 text-center">{item.affected_hosts}</td>
                  <td className="py-3 px-2 text-center">{item.cve_count}</td>
                  <td className="py-3 px-2 text-center">{item.kev_count}</td>
                  <td className="py-3 px-2 text-xs">{item.common_vulnerabilities || 'N/A'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
